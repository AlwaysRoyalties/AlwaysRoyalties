# Changelog

## 0.1.0-beta

- Process vanilla royalties for Sims in all played households on the daily royalty alarm.
- Keep off-screen processing silent.
- Initial live-save test: payments observed on two consecutive in-game days on build 1.127.41.1030.
