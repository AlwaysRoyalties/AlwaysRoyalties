"""Build the The Sims 4 script archive using Python 3.7."""

import os
import py_compile
import zipfile


ROOT = os.path.dirname(os.path.abspath(__file__))
PACKAGE = 'always_royalties'
SOURCE = os.path.join(ROOT, 'src', PACKAGE)
BUILD = os.path.join(ROOT, 'build', PACKAGE)
DIST = os.path.join(ROOT, 'dist')
ARCHIVE = os.path.join(DIST, 'AlwaysRoyalties.ts4script')


def main():
    if tuple(__import__('sys').version_info[:2]) != (3, 7):
        raise SystemExit('Use Python 3.7 to build the Sims 4 script archive.')

    if not os.path.isdir(BUILD):
        os.makedirs(BUILD)
    if not os.path.isdir(DIST):
        os.makedirs(DIST)

    modules = ('__init__', 'main')
    for module in modules:
        source_file = os.path.join(SOURCE, module + '.py')
        compiled_file = os.path.join(BUILD, module + '.pyc')
        virtual_source = PACKAGE + '/' + module + '.py'
        py_compile.compile(source_file, cfile=compiled_file,
                           dfile=virtual_source, doraise=True, optimize=2)

    with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED) as archive:
        for module in modules:
            compiled_file = os.path.join(BUILD, module + '.pyc')
            archive.write(compiled_file, PACKAGE + '/' + module + '.pyc')

    print('Built {}'.format(ARCHIVE))


if __name__ == '__main__':
    main()
