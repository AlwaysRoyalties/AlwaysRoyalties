"""Always Royalties script mod entry point."""

from . import main

