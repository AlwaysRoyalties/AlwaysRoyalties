"""Pay vanilla royalties to Sims in all played households.

This module replaces the game's daily royalty alarm callback. It keeps the
vanilla tracker, tunings, curves, multipliers, random deviation and save data.
"""

import services
import sims4.log
from sims.royalty_tracker import RoyaltyAlarmManager, RoyaltyTracker


logger = sims4.log.Logger('AlwaysRoyalties', default_owner='AlwaysRoyalties')


def _show_notification_for_active_household(self, royalty_payment_dict):
    """Keep vanilla notices for the active household only."""
    sim_info = self.sim_info
    if sim_info is None:
        return
    household = sim_info.household
    if household is services.active_household():
        return _original_show_royalty_notification(self, royalty_payment_dict)


def _pay_from_saved_tracker(sim_info, persistence_service):
    """Load, advance, pay and persist a tracker for a low-LOD SimInfo."""
    sim_proto = persistence_service.get_sim_proto_buff(sim_info.id)
    if sim_proto is None:
        return

    saved_tracker = sim_proto.attributes.royalty_tracker
    if not saved_tracker.royalties:
        return

    tracker = RoyaltyTracker(sim_info)
    tracker.load(saved_tracker)
    tracker.update_royalties_and_get_paid()
    sim_proto.attributes.royalty_tracker.CopyFrom(tracker.save())


def _royalty_alarm_tick_for_played_households(self, *_args, **_kwargs):
    """Advance every eligible Sim once when the vanilla daily alarm fires."""
    active_household = services.active_household()
    if active_household is None:
        return

    sim_info_manager = services.sim_info_manager()
    persistence_service = services.get_persistence_service()

    for sim_info in sim_info_manager.values():
        household = sim_info.household
        if household is None or not household.is_played_household:
            continue

        try:
            tracker = sim_info.royalty_tracker
            if tracker is not None:
                tracker.update_royalties_and_get_paid()
            else:
                _pay_from_saved_tracker(sim_info, persistence_service)
        except Exception as exc:
            logger.exception('Failed to process royalties for Sim {}: {}', sim_info, exc)


_original_show_royalty_notification = RoyaltyTracker.show_royalty_notification

if not getattr(RoyaltyAlarmManager, '_always_royalties_installed', False):
    RoyaltyTracker.show_royalty_notification = _show_notification_for_active_household
    RoyaltyAlarmManager._royalty_alarm_tick = _royalty_alarm_tick_for_played_households
    RoyaltyAlarmManager._always_royalties_installed = True

