# AlwaysRoyalties

A beta script mod for The Sims 4. It runs the game's existing royalty payments for authors in all played households, including households that are not currently active.

## Download and install

Download `AlwaysRoyalties.ts4script` from this repository and place it directly in `Documents/Electronic Arts/The Sims 4/Mods` (or one folder deep). Enable Script Mods in Game Options > Other, then restart the game.

The `AlwaysRoyalties_v0.1.0-beta.zip` package contains the mod and release notes. `AlwaysRoyalties_source_v0.1.0-beta.zip` contains the source project and build script.

Royalties advance while the save is open and Sim time advances. They do not accumulate while the game is closed.

## Compatibility and testing

Tested in one live save on The Sims 4 build 1.127.41.1030: an inactive played household received payments on two consecutive in-game days. Other game versions, royalty categories, saves, and mod combinations have not been independently tested.

## Source and permissions

No license has been assigned. Please do not redistribute or reuse the source without the author's permission.
